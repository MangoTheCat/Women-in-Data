library(shiny)                             # Load the Shiny library

function(input, output) {      # Set up the Shiny Server
  
 ## Server content goes here
  
}
