This is a simple example of a shiny application.

This app has a simple text input and reacts to the input by displaying the text.